# LaunchQueue Landing Page Specification

## Project Overview
- **Name**: LaunchQueue
- **Type**: SaaS Landing Page
- **Purpose**: Capture pre-launch emails for mobile indie game developers
- **Target Audience**: Indie mobile game developers (iOS/Android)

## Design System

### Color Palette
- **Background**: `#0a0a0f` (deep dark)
- **Surface**: `#111118` (card backgrounds)
- **Border**: `#1e1e2e` (subtle borders)
- **Text Primary**: `#ffffff`
- **Text Secondary**: `#a1a1aa` (muted gray)
- **Text Tertiary**: `#71717a`
- **Accent Gradient**: `linear-gradient(135deg, #8b5cf6, #3b82f6)` (purple to blue - user requested)
- **Glow Effect**: `rgba(139, 92, 246, 0.15)` (subtle purple glow)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Hero Headline**: 56px/64px, font-weight: 800
- **Section Headings**: 36px/44px, font-weight: 700
- **Card Titles**: 20px/28px, font-weight: 600
- **Body Text**: 16px/24px, font-weight: 400
- **Small Text**: 14px/20px, font-weight: 500

### Visual Elements
- **Pixel Grid Pattern**: Subtle CSS grid pattern in background (gaming aesthetic)
- **Glow Effects**: Subtle gradient glows behind key elements
- **Border Radius**: 12px for cards, 8px for buttons/inputs
- **Shadows**: Soft, subtle shadows with colored tints

## Component Structure

### 1. Navigation
- Logo (LaunchQueue text)
- "Get Early Access" button (top-right)

### 2. Hero Section
- Badge: "Finally, pre-launch marketing for mobile 📱"
- Headline: "Steam Wishlists for Mobile Games"
- Subheadline
- Email capture form (input + gradient button)
- Social proof micro-text
- Subtle animated background with pixel grid

### 3. Problem Section (Pain Points)
- 3-column grid (stacks on mobile)
- Cards with icons, titles, descriptions
- Icons: Ban, MessageSquareWarning, Unlink

### 4. Solution Section (How It Works)
- Headline
- 3 steps in horizontal timeline (vertical on mobile)
- Step number badges with gradient
- Descriptive text for each step

### 5. Testimonial Section
- Quote block with quote marks
- Attribution line

### 6. Final CTA Section
- Headline
- Email capture form (repeat)
- Background glow effect

### 7. Footer
- Brand text
- Social link

## Animations (Framer Motion)
- Fade-in-up on scroll for all sections
- Stagger delay between cards/steps
- Button hover scale effect
- Success state transition for email form
- Subtle floating animation for decorative elements

## Interactions
- Email form: Input validation, success state animation
- Smooth scroll behavior
- Hover states on all interactive elements

## Responsive Breakpoints
- Mobile: < 640px (single column)
- Tablet: 640px - 1024px (2 columns where applicable)
- Desktop: > 1024px (full layout)

## Technical Implementation
- React with TypeScript
- Tailwind CSS for styling
- Framer Motion for animations
- Lucide React for icons
- Single-page application